from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, SubmitField
from wtforms.validators import DataRequired
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# In-memory user storage (for demonstration purposes)
users = {}

class User(UserMixin):
    def __init__(self, username, password):
        self.id = username  # Required for UserMixin
        self.username = username
        self.password = generate_password_hash(password)

# Auction and Bid classes
class Bid:
    def __init__(self, bidder, amount):
        self.bidder = bidder
        self.amount = amount

class Auction:
    def __init__(self, item_name, starting_bid):
        self.item_name = item_name
        self.starting_bid = starting_bid
        self.highest_bid = None
        self.bids = []

    def place_bid(self, bidder, amount):
        print(f"Placing bid: {bidder} - {amount}")  # Debugging output
        if amount <= self.starting_bid:
            return "Bid must be higher than the starting bid."
        if self.highest_bid and amount <= self.highest_bid.amount:
            return "Bid must be higher than the current highest bid."

        new_bid = Bid(bidder, amount)
        self.bids.append(new_bid)
        self.highest_bid = new_bid  # Update the highest bid to the new bid
        print(f"New highest bid: {self.highest_bid.amount} by {self.highest_bid.bidder}")  # Debugging output
        return "Bid placed successfully."


auctions = {}

@login_manager.user_loader
def load_user(username):
    return users.get(username)

# Forms
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Register')

class AuctionForm(FlaskForm):
    item_name = StringField('Item Name', validators=[DataRequired()])
    starting_bid = FloatField('Starting Bid', validators=[DataRequired()])
    submit = SubmitField('Create Auction')


@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/index')
@login_required
def index():
    return render_template('index.html', auctions=auctions)

@app.route('/create_auction', methods=['GET', 'POST'])
@login_required
def create_auction():
    form = AuctionForm()
    if form.validate_on_submit():
        item_name = form.item_name.data
        starting_bid = form.starting_bid.data
        auctions[item_name] = Auction(item_name, starting_bid)
        flash('Auction created successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('create_auction.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = users.get(form.username.data)
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        else:
         flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        if username in users:
            flash('Username already exists', 'danger')
        else:
            users[username] = User(username, password)
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
    return render_template('register.html', form=form)
@app.route('/auction/<item_name>', methods=['GET', 'POST'])
@login_required
def auction_view(item_name):
    auction_item = auctions.get(item_name)  # Renamed the variable
    if auction_item is None:
        flash('Auction not found', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        amount = float(request.form['amount'])
        message = auction_item.place_bid(current_user.username, amount)
        flash(message, 'info')
        return redirect(url_for('auction_view', item_name=item_name))  # Update the redirect

    return render_template('auction.html', auction=auction_item)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
